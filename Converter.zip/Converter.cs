﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            String[] a = { "Celsius", "Farenheit" };
            String[] b = {"Farenheit", "Celsius"};
            comboBox1.DataSource = a;
            comboBox2.DataSource = b;
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
            
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            {
                double startingTemp, resultTemp;
                startingTemp = double.Parse(textBox1.Text);
                if (comboBox1.Text == "Celsius" && comboBox2.Text == "Farenheit")
                {
                    resultTemp = (startingTemp * (1.8) + 32);
                    label3.Text = resultTemp.ToString();
                }
                if (comboBox1.Text == "Farenheit" && comboBox2.Text == "Celsius")
                    
                {
                    resultTemp = ((startingTemp - 32) / 1.8);
                    label3.Text = resultTemp.ToString();
                }
            }
        }
    }
}
